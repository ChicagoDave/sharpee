The Ides of March
=================

A complete Sharpee story, written in Chord. Three days before Julius Caesar
opens the new Globe, and you are Henslowe's man among the hired players.

This is the conversation sample: where The Folly at Fernhill shows the world —
rooms, things, puzzles, time — this one shows people. Every character carries a
personality, a temperament, moods that move, things they know and will or will
not repeat, and conversations they will steer back to whether you want them to
or not.


WHAT IS HERE
------------

  ides-of-march.story        The whole story. This is the only file you write.
  ides-of-march.tests.json   Its tests, recorded by playing in the Testing tab.
  ides-of-march.config.json  The story's identity (its IFID). The tool maintains
                             this — you never edit it, and you should keep it if
                             you put the story in version control.
  WALKTHROUGH.txt            The complete solution, with every response the game
                             gives. Total spoilers — read it only if you want
                             them.


OPENING IT IN CHORD WRITER
--------------------------

  1. Move this folder somewhere you keep your work — your Documents folder
     is a fine choice.
  2. Open Chord Writer, choose Open…, and select this folder.
  3. Press Cmd-B to build, and the story starts in the Play tab.

Nothing to install and nothing to configure: Chord Writer carries its own
toolchain.


OPENING IT FROM THE TERMINAL
----------------------------

If you would rather use the command line, install the CLI once:

    npm install -g @sharpee/devkit

then, from inside this folder:

    sharpee build          compile it and build the browser app
    sharpee play           play it in the terminal
    sharpee test           replay the recorded tests

Requires Node.js 18 or newer.


WHAT TO READ IN THE SOURCE
--------------------------

The conversation constructs are what this story is for. Look for:

  define manner          how a character delivers lines in a given mood
  define greetings       first meetings, returns, and being asked once too often
  define exchange        a question the character asks YOU
  define initiative      speaking without being spoken to
  define conversation    a thread carried across turns, scenes, and days

Kemp's defection is a blocking thread: he will keep steering back to it until
it is settled. Shakespeare's suspicion is a passive one: he lets it drift and
always returns. Try "tell me more" or "go on" when someone has more to say.


WHERE TO READ MORE
------------------

  https://sharpee.net/chord/guide/characters-and-conversation   characters and conversation
  https://sharpee.net/chord                                      the Chord language guide
  https://sharpee.net/chord-writer                               the Chord Writer app
