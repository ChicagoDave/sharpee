The Folly at Fernhill
=====================

A complete Sharpee story, written in Chord. One winter night to find the deed.

This is the sample project: real, finished, and small enough to read in a
sitting. Open it, play it, break it, and change it.


WHAT IS HERE
------------

  fernhill.story        The whole story. This is the only file you write.
  fernhill.tests.json   Its tests, recorded by playing in the Testing tab.
  fernhill.config.json  The story's identity (its IFID). The tool maintains
                        this — you never edit it, and you should keep it if
                        you put the story in version control.
  assets/               Audio and images the story plays.
  browser/index.html    A custom page for the browser build.
  WALKTHROUGH.txt       The complete solution, with every response the game
                        gives. Total spoilers — read it only if you want them.


OPENING IT IN CHORD WRITER
--------------------------

  1. Move this folder somewhere you keep your work — your Documents folder
     is a fine choice.
  2. Open Chord Writer, choose Open…, and select this folder.
  3. Press Cmd-B to build, and the story starts in the Play tab.

Nothing to install and nothing to configure: Chord Writer carries its own
toolchain.


OPENING IT FROM THE TERMINAL
----------------------------

If you would rather use the command line, install the CLI once:

    npm install -g @sharpee/devkit

then, from inside this folder:

    sharpee build          compile it and build the browser app
    sharpee play           play it in the terminal
    sharpee test           replay the recorded tests

Requires Node.js 18 or newer.


WHERE TO READ MORE
------------------

  https://sharpee.net/learn/fernhill      how this story is built, chapter by chapter
  https://sharpee.net/chord               the Chord language guide
  https://sharpee.net/chord-writer        the Chord Writer app
